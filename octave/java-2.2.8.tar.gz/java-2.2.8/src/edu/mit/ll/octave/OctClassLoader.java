/*
 *%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 *% (c) <2010> Massachusetts Institute of Technology
 *%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

package edu.mit.ll.octave;

import java.io.File;

/*  Custom class loader
 *
 */
public class OctClassLoader extends java.net.URLClassLoader
{
  public OctClassLoader ()
    {
      super (new java.net.URL[0]);
    }

  public OctClassLoader (ClassLoader parent)
    {
      super (new java.net.URL[0], parent);
    }

  protected Class findClass (String name) throws ClassNotFoundException
    {
      //System.out.println ("Looking for class " + name);
      return super.findClass (name);
    }

  protected String findLibrary (String libname)
    {
      // Look dynamically into java.library.path, because Sun VM does
      // not do it (seems to cache initial java.library.path instead)

      String[] paths = System.getProperty ("java.library.path").split (File.pathSeparator);
      
      libname = System.mapLibraryName (libname);
      for (int i=0; i<paths.length; i++)
        {
          File f = new File (paths[i], libname);
          if (f.exists ())
            return f.getAbsolutePath();
        }

      return null;
    }

  public void addClassPath (String name) throws Exception
    {
      java.io.File f = new java.io.File (name);
      addURL (f.toURI ().toURL ());
    }

  public void removeClassPath (String name) throws Exception
    {
      throw new Exception ("not implemented yet");
    }
}
