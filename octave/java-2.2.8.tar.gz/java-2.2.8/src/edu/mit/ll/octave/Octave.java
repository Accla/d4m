/* 
 *%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 *% (c) <2010> Massachusetts Institute of Technology
 *%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

package edu.mit.ll.octave;

import java.util.List;
import java.util.LinkedList;

public class Octave
{
  static
  {
    System.load (System.getProperty ("octave.java.path") + java.io.File.separator + "__java__.oct");
  }

  private static Object m_notifyObj = null;
  private static Object[] m_args = null;
  private static LinkedList m_invokeLst = new LinkedList();
  private static LinkedList m_waitLst = new LinkedList();

  public native static boolean call (String name, Object[] argin, Object[] argout);
  public native static void doInvoke(int ID, Object[] args);
  public native static void doEvalString(String cmd);
  public native static boolean needThreadedInvokation();

  public static void checkPendingAction()
    {
      if (m_notifyObj != null)
        {
          synchronized(m_notifyObj)
            {
              if (m_notifyObj instanceof OctaveReference)
                doInvoke(((OctaveReference)m_notifyObj).getID(), m_args);
              else if (m_notifyObj instanceof String)
                doEvalString((String)m_notifyObj);
              m_notifyObj.notifyAll();
            }
          m_notifyObj = null;
          m_args = null;
        }

      Object obj=null;
      Object[] objArgs=null;

      while (true)
        {
          obj = null;
          objArgs = null;

          synchronized (m_invokeLst)
            {
              if (m_invokeLst.size() > 0)
                {
                  obj = m_invokeLst.remove();
                  if (obj instanceof OctaveReference)
                    objArgs = (Object[])m_invokeLst.remove();
                }
            }

          if (obj != null)
            {
              if (obj instanceof Runnable)
                ((Runnable)obj).run();
              else if (obj instanceof OctaveReference)
                doInvoke(((OctaveReference)obj).getID(), objArgs);
              else if (obj instanceof String)
                doEvalString((String)obj);
            }
          else
            break;
        }
    }

  private static void checkWaitState()
    {
      if (m_waitLst.size() > 0)
        {
          Object wObj = m_waitLst.getFirst();
          synchronized (wObj)
            {
              wObj.notifyAll();
            }
        }
    }

  public static void invokeAndWait(OctaveReference ref, Object[] invokeArgs)
    {
      if (needThreadedInvokation())
        {
          synchronized(ref)
            {
              m_notifyObj = ref;
              m_args = invokeArgs;
              try { checkWaitState(); ref.wait(); }
              catch (InterruptedException e) {}
            }
        }
      else
        doInvoke(ref.getID(), invokeArgs);
    }

  public static void evalAndWait(String cmd)
    {
      if (needThreadedInvokation())
        {
          synchronized(cmd)
            {
              m_notifyObj = cmd;
              m_args = null;
              try { checkWaitState(); cmd.wait(); }
              catch (InterruptedException e) {}
            }
        }
      else
        doEvalString(cmd);
    }

  public static void invokeLater(Runnable r)
    {
      if (needThreadedInvokation())
        synchronized(m_invokeLst)
          {
            m_invokeLst.add(r);
            checkWaitState();
          }
      else
        r.run();
    }

  public static void invokeLater(OctaveReference ref, Object[] invokeArgs)
    {
      if (needThreadedInvokation())
        synchronized(m_invokeLst)
          {
            m_invokeLst.add(ref);
            m_invokeLst.add(invokeArgs);
            checkWaitState();
          }
      else
        doInvoke(ref.getID(), invokeArgs);
    }

  public static void evalLater(String cmd)
    {
      if (needThreadedInvokation())
        synchronized(m_invokeLst)
          {
            m_invokeLst.add(cmd);
            checkWaitState();
          }
      else
        doEvalString(cmd);
    }

  public static void waitFor(Object wObj)
    {
      m_waitLst.add(0, wObj);
      synchronized (wObj)
        {
          while (m_waitLst.size() > 0 && m_waitLst.getFirst() == wObj)
            {
              try { wObj.wait(); }
              catch (InterruptedException e) {}
              checkPendingAction();
            }
        }
    }

  public static void endWaitFor(Object obj)
    {
      boolean isCurrentWaitObject = (m_waitLst.size() > 0 && m_waitLst.getFirst() == obj);

      m_waitLst.remove(obj);
	  if (needThreadedInvokation() && isCurrentWaitObject)
        synchronized (obj)
          {
            obj.notifyAll();
          }
    }

  public static Object do_test (String name, Object arg0) throws Exception
    {
      Object[] argin = new Object[] { arg0 };
	  Object[] argout = new Object[1];
      if (call (name, argin, argout))
        return argout[0];
      throw new Exception ("octave call failed");
    }
}
