/*
 *%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 *% (c) <2010> Massachusetts Institute of Technology
 *%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*/

package edu.mit.ll.octave;

public class OctaveReference
{
	static
	{
		System.load (System.getProperty ("octave.java.path") + java.io.File.separator + "__java__.oct");
	}
  
	private int m_ID;

	public OctaveReference(int ID)
	{
		this.m_ID = ID;
	}

	private native static void doFinalize(int ID);

	protected void finalize() throws Throwable
	{
		doFinalize(this.m_ID);
	}

	public String toString()
	{
		return ("<octave reference " + this.m_ID + ">");
	}

	public int getID()
	{
		return this.m_ID;
	}

	public Object invoke(Object[] args)
	{
		//System.out.println("OctaveReference::invoke");
		Octave.doInvoke(this.m_ID, args);
		return null;
	}

	public synchronized Object invokeAndWait(Object[] args)
	{
		//System.out.println("OctaveReference::invokeandWait");
		Octave.invokeAndWait(this, args);
		return null;
	}
}
