function b = double (a)
  b = a.poly;
endfunction
