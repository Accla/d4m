function y = mtimes (a, b)
  y = polynomial (conv (double(a),double(b)));
endfunction