function display (f)

  display(f.polynomial);

endfunction

