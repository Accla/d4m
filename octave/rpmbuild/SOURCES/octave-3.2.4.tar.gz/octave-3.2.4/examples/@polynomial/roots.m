function y = roots (p)
  y = roots(fliplr(p.poly));
endfunction