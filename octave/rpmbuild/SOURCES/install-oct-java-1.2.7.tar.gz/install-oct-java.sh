#!/usr/local/bin/octave
pkg install /var/tmp/java-1.2.7.tar.gz
