

d4m_home=getenv('D4M_HOME');
addpath([d4m_home, '/matlab_src'])
addpath([d4m_home, '/examples'])
addpath([d4m_home, '/matlab_src/html'])